package com.example.whatsappclone;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_MEDIA = 100;
    private static final int PICK_DOCUMENT = 101;
    private static final int PICK_CONTACT = 102;
    private static final int TAKE_PHOTO = 103;
    private static final int REQ_PERMISSIONS = 500;

    private static final int GREEN = Color.rgb(7, 94, 84);
    private static final int GREEN_2 = Color.rgb(18, 140, 126);
    private static final int CHAT_BG = Color.rgb(239, 234, 226);
    private static final int TEXT = Color.rgb(17, 27, 33);
    private static final int MUTED = Color.rgb(102, 119, 129);

    private LinearLayout body;
    private LinearLayout shell;
    private LinearLayout toolbar;
    private TextView toolbarTitle;
    private ImageButton searchButton;
    private LinearLayout tabs;
    private EditText composer;
    private LinearLayout messages;
    private ScrollView messageScroll;
    private SharedPreferences preferences;
    private String currentChat;

    private final String[] names = {"Amit Kumar", "Priya Sharma", "Rahul Verma", "Office Group", "Family", "Neha Singh", "Rohit Patel"};
    private final String[] previews = {"Okay, see you tomorrow", "Photo", "Let's meet at 6 PM", "You: document sent", "Mom: Dinner ready", "Thank you!", "Voice message"};
    private final String[] times = {"10:42 AM", "9:18 AM", "Yesterday", "Yesterday", "Monday", "Sunday", "Sunday"};

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences("vijendra", MODE_PRIVATE);
        getWindow().setStatusBarColor(GREEN);
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= 26) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        requestPermissionsIfNeeded();
        buildUi();
        showChats();
    }

    private void requestPermissionsIfNeeded() {
        ArrayList<String> permissions = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS);
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES);
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO);
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) permissions.add(Manifest.permission.READ_CONTACTS);
        if (!permissions.isEmpty()) requestPermissions(permissions.toArray(new String[0]), REQ_PERMISSIONS);
    }

    private void buildUi() {
        shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(Color.WHITE);
        setContentView(shell);

        toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(16), dp(6), dp(6), dp(6));
        toolbar.setBackgroundColor(GREEN);
        shell.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(62)));

        toolbarTitle = text("Vijendra", 22, Color.WHITE);
        toolbarTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        toolbar.addView(toolbarTitle, new LinearLayout.LayoutParams(0, -1, 1));

        searchButton = icon(android.R.drawable.ic_menu_search, "Search");
        searchButton.setOnClickListener(v -> showSearch());
        toolbar.addView(searchButton, new LinearLayout.LayoutParams(dp(48), dp(48)));
        ImageButton menu = icon(android.R.drawable.ic_menu_more, "Menu");
        menu.setOnClickListener(v -> Toast.makeText(this, "Vijendra menu", Toast.LENGTH_SHORT).show());
        toolbar.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(48)));

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setBackgroundColor(Color.WHITE);
        shell.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        tabs = new LinearLayout(this);
        tabs.setGravity(Gravity.CENTER);
        tabs.setBackgroundColor(Color.WHITE);
        String[] labels = {"CHATS", "UPDATES", "COMMUNITIES", "CALLS"};
        for (int i = 0; i < labels.length; i++) {
            final int tab = i;
            TextView t = text(labels[i], 11, GREEN);
            t.setGravity(Gravity.CENTER);
            t.setTypeface(null, android.graphics.Typeface.BOLD);
            t.setOnClickListener(v -> { if (tab == 0) showChats(); else if (tab == 1) showUpdates(); else if (tab == 2) showCommunities(); else showCalls(); });
            tabs.addView(t, new LinearLayout.LayoutParams(0, dp(50), 1));
        }
        shell.addView(tabs, new LinearLayout.LayoutParams(-1, dp(50)));
    }

    private void showChats() {
        resetPage("Vijendra");
        for (int i = 0; i < names.length; i++) {
            final String name = names[i];
            LinearLayout row = chatRow(name, previews[i], times[i], i);
            body.addView(row, new LinearLayout.LayoutParams(-1, dp(76)));
        }
        TextView add = text("+", 30, Color.WHITE);
        add.setGravity(Gravity.CENTER);
        add.setBackground(circle(GREEN_2));
        add.setElevation(dp(8));
        add.setOnClickListener(v -> showNewChat());
        body.post(() -> {
            ViewGroup parent = (ViewGroup) body.getParent();
            parent.addView(add, new LinearLayout.LayoutParams(dp(58), dp(58)));
        });
    }

    private LinearLayout chatRow(String name, String preview, String time, int seed) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(5), dp(14), dp(5));
        ImageView avatar = avatar(name, 54, seed);
        row.addView(avatar, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14), 0, 0, 0);
        LinearLayout top = new LinearLayout(this);
        TextView n = text(name, 16, TEXT); n.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView tm = text(time, 12, MUTED); tm.setGravity(Gravity.RIGHT);
        top.addView(n, new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(tm, new LinearLayout.LayoutParams(dp(75), -2));
        info.addView(top);
        info.addView(text(preview, 14, MUTED), new LinearLayout.LayoutParams(-1, dp(30)));
        row.addView(info, new LinearLayout.LayoutParams(0, -1, 1));
        row.setOnClickListener(v -> openChat(name));
        return row;
    }

    private void openChat(String name) {
        currentChat = name;
        toolbar.setVisibility(View.GONE);
        tabs.setVisibility(View.GONE);
        body.removeAllViews();
        body.setBackgroundColor(CHAT_BG);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(4), 0, dp(4), 0);
        top.setBackgroundColor(GREEN);
        ImageButton back = icon(android.R.drawable.ic_media_previous, "Back");
        back.setOnClickListener(v -> closeChat());
        top.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        top.addView(avatar(name, 38, Math.abs(name.hashCode())), new LinearLayout.LayoutParams(dp(38), dp(38)));
        TextView title = text(name, 17, Color.WHITE); title.setTypeface(null, android.graphics.Typeface.BOLD); title.setPadding(dp(10), 0, 0, 0);
        top.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        ImageButton call = icon(android.R.drawable.ic_menu_call, "Call");
        call.setOnClickListener(v -> dial());
        top.addView(call, new LinearLayout.LayoutParams(dp(48), dp(48)));
        body.addView(top, new LinearLayout.LayoutParams(-1, dp(56)));

        messageScroll = new ScrollView(this);
        messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); messages.setPadding(dp(10), dp(12), dp(10), dp(12));
        messageScroll.addView(messages);
        body.addView(messageScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        addBubble("Hello! Welcome to Vijendra.", false);
        addBubble("You can test local chat, media and documents.", false);

        LinearLayout composerBar = new LinearLayout(this);
        composerBar.setGravity(Gravity.CENTER_VERTICAL);
        composerBar.setPadding(dp(6), dp(6), dp(6), dp(6));
        composerBar.setBackgroundColor(CHAT_BG);
        ImageButton attach = icon(android.R.drawable.ic_menu_add, "Attachment"); attach.setOnClickListener(v -> showAttachments());
        composerBar.addView(attach, new LinearLayout.LayoutParams(dp(46), dp(48)));
        composer = new EditText(this); composer.setHint("Message"); composer.setSingleLine(true); composer.setTextSize(16); composer.setBackground(round(Color.WHITE, 24)); composer.setPadding(dp(14), dp(4), dp(14), dp(4));
        composerBar.addView(composer, new LinearLayout.LayoutParams(0, dp(48), 1));
        ImageButton send = icon(android.R.drawable.ic_menu_send, "Send"); send.setOnClickListener(v -> sendMessage());
        composerBar.addView(send, new LinearLayout.LayoutParams(dp(50), dp(48)));
        body.addView(composerBar, new LinearLayout.LayoutParams(-1, dp(60)));
    }

    private void closeChat() { currentChat = null; toolbar.setVisibility(View.VISIBLE); tabs.setVisibility(View.VISIBLE); body.setBackgroundColor(Color.WHITE); showChats(); }

    private void addBubble(String value, boolean mine) {
        TextView bubble = text(value, 15, TEXT);
        bubble.setPadding(dp(12), dp(8), dp(12), dp(8));
        bubble.setBackground(round(mine ? Color.rgb(220,248,198) : Color.WHITE, 14));
        LinearLayout wrap = new LinearLayout(this); wrap.setGravity(mine ? Gravity.RIGHT : Gravity.LEFT); wrap.setPadding(dp(6), dp(3), dp(6), dp(3));
        wrap.addView(bubble, new LinearLayout.LayoutParams(-2, -2));
        messages.addView(wrap);
        messageScroll.post(() -> messageScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void sendMessage() { if (composer == null) return; String value = composer.getText().toString().trim(); if (value.isEmpty()) return; addBubble(value, true); composer.setText(""); }

    private void showUpdates() { resetPage("Updates"); addSection("My status", "Tap to add status"); addSection("Recent updates", "Amit Kumar • Today, 9:20 AM"); addSection("Channels", "Vijendra News"); }
    private void showCommunities() { resetPage("Communities"); addSection("Family Community", "Announcements • Groups"); addSection("Office Community", "Announcements • Groups"); addSection("Friends Community", "Announcements • Groups"); }
    private void showCalls() { resetPage("Calls"); addSection("Amit Kumar", "Today, 10:42 AM • Outgoing"); addSection("Priya Sharma", "Yesterday • Incoming"); }

    private void addSection(String title, String subtitle) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(16), dp(10), dp(16), dp(10));
        row.addView(avatar(title, 52, Math.abs(title.hashCode())), new LinearLayout.LayoutParams(dp(52), dp(52)));
        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(14), 0, 0, 0); info.addView(text(title, 16, TEXT)); info.addView(text(subtitle, 13, MUTED));
        row.addView(info, new LinearLayout.LayoutParams(0, -1, 1)); body.addView(row, new LinearLayout.LayoutParams(-1, dp(76)));
    }

    private void showNewChat() { resetPage("New chat"); addSection("New group", "Create a group"); addSection("New contact", "Save a contact"); for (String n : names) addSection(n, "Available on Vijendra"); }

    private void showSearch() {
        final EditText input = new EditText(this); input.setSingleLine(true); input.setHint("Search chats"); input.setTextColor(Color.WHITE); input.setHintTextColor(0x99FFFFFF); input.setBackgroundColor(Color.TRANSPARENT);
        toolbarTitle.setVisibility(View.GONE); searchButton.setVisibility(View.GONE); toolbar.addView(input, 0, new LinearLayout.LayoutParams(0, dp(48), 1));
        input.requestFocus();
    }

    private void showAttachments() {
        Toast.makeText(this, "Choose: Gallery, Document, Contact or Camera", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.setType("*/*"); intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); startActivityForResult(intent, PICK_DOCUMENT);
    }

    private void dial() { try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))); } catch (Exception e) { Toast.makeText(this, "Dialer unavailable", Toast.LENGTH_SHORT).show(); } }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && currentChat != null) {
            if (requestCode == PICK_DOCUMENT) addBubble("📄 Document selected", true);
            else if (requestCode == PICK_MEDIA) addBubble("🖼 Image selected", true);
            else if (requestCode == PICK_CONTACT) addBubble("👤 Contact selected", true);
            else if (requestCode == TAKE_PHOTO) addBubble("📷 Photo captured", true);
        }
    }

    private void resetPage(String title) { currentChat = null; toolbar.setVisibility(View.VISIBLE); tabs.setVisibility(View.VISIBLE); toolbarTitle.setVisibility(View.VISIBLE); searchButton.setVisibility(View.VISIBLE); toolbarTitle.setText(title); body.removeAllViews(); body.setBackgroundColor(Color.WHITE); }
    private TextView text(String value, float size, int color) { TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); v.setGravity(Gravity.CENTER_VERTICAL); return v; }
    private ImageButton icon(int resource, String description) { ImageButton b = new ImageButton(this); b.setImageResource(resource); b.setContentDescription(description); b.setColorFilter(Color.WHITE); b.setBackgroundColor(Color.TRANSPARENT); b.setPadding(dp(8), dp(8), dp(8), dp(8)); return b; }
    private ImageView avatar(String name, int size, int seed) { ImageView v = new ImageView(this); GradientDrawable g = new GradientDrawable(); g.setShape(GradientDrawable.OVAL); int[] colors = {0xFF7E57C2,0xFF26A69A,0xFFEF5350,0xFFFFA726,0xFF42A5F5,0xFFAB47BC}; g.setColor(colors[Math.abs(seed) % colors.length]); v.setBackground(g); v.setImageResource(android.R.drawable.ic_menu_myplaces); v.setColorFilter(Color.WHITE); v.setPadding(dp(size/3), dp(size/3), dp(size/3), dp(size/3)); return v; }
    private GradientDrawable round(int color, int radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g; }
    private GradientDrawable circle(int color) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setShape(GradientDrawable.OVAL); return g; }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override public void onBackPressed() { if (currentChat != null) closeChat(); else super.onBackPressed(); }
}
