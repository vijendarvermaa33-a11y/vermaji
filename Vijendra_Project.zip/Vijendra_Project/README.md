# Vijendra — Android Studio Java/XML

A native Android Vijendra-style clone starter designed to build with Java 17 and Gradle 8.9.

## Current Android features
- Chats, Updates, Communities and Calls tabs
- Search chats
- New chat/contact picker
- One-to-one chat UI
- Local message persistence with SharedPreferences
- Text and emoji messages
- Gallery, camera, document and contact attachment actions
- Local voice-note recording
- Status/Updates UI
- Communities and announcement UI
- Calls list, phone dial action and video-call placeholder
- Settings/account/privacy/chats/notifications/storage/help screens
- Runtime permissions for camera, microphone, contacts, media and notifications
- Android 23+ support, target/compile SDK 35

## Build requirements
- Android Studio Ladybug or newer
- JDK 17
- Gradle 8.9
- Android SDK 35

## Important production note
This project is a native Android client foundation. Real Vijendra-scale functionality needs a backend:
OTP/phone authentication, realtime messaging, FCM push notifications, cloud media, group synchronization, presence, end-to-end encryption, multi-device sync, status expiry/viewers, and voice/video call signaling/media infrastructure.

For iPhone, the Android Java/XML project cannot itself be compiled as an iOS app. The same backend can be shared with a separate iOS client written in Swift/SwiftUI.
