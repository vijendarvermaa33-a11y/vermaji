# Vijendra-style clone feature map

## Working locally in this Android project
- Splash screen and launcher icon
- Chats / Updates / Communities / Calls navigation
- Chat list and search
- One-to-one chat UI
- Local message history
- Text/emoji sending
- Attachment actions: gallery, camera, document, contact
- Local voice-note recording
- Status composer/viewer UI
- Communities/announcement UI
- Calls list and phone dial action
- Settings/account/privacy/chats/notifications/storage/help UI
- Android runtime permission handling

## Requires backend integration for real multi-user operation
- OTP/phone-number registration and login
- Realtime one-to-one/group messaging
- Delivery/read receipts and typing/presence
- FCM push notifications
- Cloud media upload/download
- Contact discovery/block/report synchronization
- Group/admin/community/channel synchronization
- Status expiry and viewer tracking
- Voice/video call signaling, TURN/STUN and media servers
- Multi-device sessions and linked devices
- Encrypted backup and payment/business APIs
